#!/usr/bin/python3
# 2020.06.01
# Author Zhang Yihao

from collections import defaultdict
import json

dataName = "ml-1m"
num_link = 0  # the number of each user link to items
# num_bought = 10

# user -> item
ui_dict = defaultdict(list)
iu_dict = defaultdict(list)
reviews_data = []

with open('G:/Datasets/MovieLens Datasets/' + dataName + '/' + 'ratings.dat') as f:
    for line in f:
        reviews_data.append(line)
    f.close()

for line_data in reviews_data:
    str_sp = line_data.split("::")
    user_id = str_sp[0]
    item_id = str_sp[1]
    ui_dict[user_id].append(item_id)
    iu_dict[item_id].append(user_id)
print("len(ui_dict)=====", len(ui_dict))
print("len(iu_dict)=====", len(iu_dict))

ex_data = open('../data/' + dataName + '.txt', "w")
for line in reviews_data:
    str_sp = line.split("::")
    user_id = str_sp[0]
    item_id = str_sp[1]
    score = str_sp[2]
    stmp = str_sp[3]
    ui_num = len(ui_dict[user_id])
    if ui_num >= num_link:
        ex_data.writelines(user_id + ' ' + item_id + "\n")
ex_data.close()
