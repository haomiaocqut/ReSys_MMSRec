#!/usr/bin/python3
# 2019.12.02
# Author Zhang Yihao

import json
import numpy as np
from collections import defaultdict

dataName = "Yelp"
iu_dict = defaultdict(list)
ui_dict = defaultdict(list)
reviews_data = []
reviews_train_data = []
reviews_test_data = []

global max_num_item  # 最大items编号
global max_num_user  # 最大items编号
global line_num  # 最大items编号

line_num = 1
with open('../data/' + dataName + '/' + dataName, encoding='UTF-8') as f:
    for line in f:
        line_dict = json.dumps(eval(line))
        reviews_data.append(json.loads(line_dict))
        line_num += 1
    f.close()

'''建立ID和Num的对应关系 '''
asin2itemNum = {}
reviewerID2userNum = {}
num = 1
for ui in reviews_data:
    if ui["business_id"] not in asin2itemNum:
        asin2itemNum[ui["business_id"]] = num
        num += 1
num = 1
for uu in reviews_data:
    if uu["user_id"] not in reviewerID2userNum:
        reviewerID2userNum[uu["user_id"]] = num
        num += 1

# loading_user_items
max_num_item = 1
max_num_user = 1

for d in reviews_data:
    user_id = reviewerID2userNum.get(d["user_id"])
    item_id = asin2itemNum.get(d["business_id"])
    if user_id not in ui_dict:
        ui_dict[user_id] = list()
        if int(user_id) > max_num_user:
            max_num_user = int(user_id)
    ui_dict[user_id].append(item_id)
    if item_id not in iu_dict:
        iu_dict[item_id] = list()
        if int(item_id) > max_num_item:
            max_num_item = int(item_id)
    iu_dict[item_id].append(user_id)

print("Interaction_num=====", line_num)
print("max_num_user=====", max_num_user)
print("max_num_item=====", max_num_item)
sparse_value = 1-(line_num/(max_num_item*max_num_user))
print("sparse_value=====", sparse_value*100)
